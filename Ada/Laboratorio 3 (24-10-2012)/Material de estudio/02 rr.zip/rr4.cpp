#include<iostream>
#include<unistd.h>
 
using namespace std;
 
int main(){
    int numberOfProcesses;
    int i;
    int timeSlot;
    int hover = 0;
 
    //number of processes
    cout << "\nNUMBER OF PROCESSES: ";
    cin >> numberOfProcesses;
    int burstTime[numberOfProcesses];
 
    //time slot
    cout << "TIME SLOT:";
    cin >> timeSlot;
 
    //burst time
    for(i=0; i<numberOfProcesses; i++){
        cout << "******************************\n";
        cout << "PROCESS " << i+1 << "\n";
        cout << "\tBURST TIME: ";
        cin>>burstTime[i];
    }
 
    //display burst time
    cout << "\n================================\n";
    cout << "     PROCESS\t    BURST TIME\t   ";
    for(i=0; i<numberOfProcesses; i++){
        cout << "\n    P"<<i+1<<"\t\t"<<burstTime[i];
        hover += burstTime[i];
    }
    cout << "\n================================\n\n";
 
    //start process execution
    int sec = timeSlot;
    while(hover != 0){
        for(i = 0; i < numberOfProcesses; i++){
            if(burstTime[i] > 0){
                if(burstTime[i] > timeSlot){
                    sleep(timeSlot);
                    burstTime[i] -= timeSlot;
                    hover -= timeSlot;
                    cout << "at " << sec <<"s\tPROCESS P";
                    cout << i+1 << " is running ......\n";
                    sec += timeSlot;
                }else{
                    sleep(burstTime[i]);
                    hover -= burstTime[i];
                    cout << "at " << sec <<"s\tPROCESS P";
                    cout << i+1 <<" has completed\n";
                    sec += burstTime[i];
                    burstTime[i] = 0;
                }
                 
            }
        }
    }
    return 0;
} 
