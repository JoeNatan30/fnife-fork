#include<stdio.h>
main()
{ 
   int i,ptime[10][10],a[10][10],n,I,j,k=0,sum=0,q;
   float avg;

   printf("enter the no of process \t \t");
   scanf("%d",&n);
   for(i=0;i<10;i++) {
      for(j=0;j<10;j++) {
           ptime[i][j]=0;
           a[i][j]=0;
       }
   }
   for(i=0;i<n;i++) {
       j=0;
       printf("\n enter the processname & time for process %d \t",i+1);
       scanf("%s",&a[i][j]);
       scanf("%d",&ptime[i][j]);
   }
   printf("enter the time quantum\t\t");
   scanf("%d",&q);
   printf("\n \t processname \t\t process time\t\t quantum time \t\t");
   for(i=0;i<n;i++) {
      printf("\t%d\t\t%d\t\t%d\n",i+1,ptime[i][0],q);
   }
   printf("\n Round robin");
   for(j=0;j<10;i++) {
     for(i=0;i<n;i++)  {
         a[2*j][i]=k;
         if((ptime[i][j]<=q)&&(ptime[i][j]!=0)) {
              ptime[i][j+1]=0;
              printf("\t\tprocess %d is from %d to %d \n",i+1,k,(k+ptime[i][j]));
              k+=ptime[i][j];
              a[2*j+1][i]=k;
         } else if(ptime[i][j]!=0) {
                    ptime[i][j+1]=ptime[i][j]-q;
                    printf("\t\tprocess %d is from %d to %d\n",i+1,k,(k+q));
                    k+=q;
                    a[2*j+1][i]=k;
                } else {
                         a[2*j][i]=0;
                         a[2*j+1][i]=0;
                }
     }
   }
   for(i=0;i<n;i++) {
         sum+=a[0][i];
   }
   for(i=0;i<n;i++) {
       for(j=1;j<10;j++) {
            if((a[j][i]!=0)&&(a[j+1][i]!=0)&&((j+1)%2==0)) {
                sum+=a[j+1][i]-a[j][i];
            }
        }
   }
   avg=(float)sum/n;
   printf("\n\n the avg waiting time is \t %2f ms",avg);
   sum=avg=0;
   for(j=0;j<n;j++) {
      I=1;
      while(a[i][j]!=0) {
         i+=1;
      }
      sum+=a[i-1][j];
   }
   avg=(float)sum/n;
   printf("\n\nthe turn around time is %2f ms",avg);
   return 0;
}
