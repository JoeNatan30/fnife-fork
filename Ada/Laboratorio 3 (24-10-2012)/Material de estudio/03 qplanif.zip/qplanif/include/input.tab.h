typedef union {
  long  ivalue;
  char  *cvalue;
} YYSTYPE;
#define	NUM	258
#define	TAREA	259
#define	RECURSO	260
#define	CPU	261
#define	OFFSET	262
#define	PERIODO	263
#define	PRIORIDAD	264
#define	IDEN	265


extern YYSTYPE yylval;
