#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>

#define MAX_STR 256 
#define MAX_LINE 64
#define MAX_PROCS 256

#define BLOCK 0
#define READY 1
#define RUNNING 2

#define DEBUG true
#define true 1
#define false 0

/* Priority Hierarchy */
#define MAX_PRIORITY 4
#define CLASS_0 0
#define CLASS_1 1
#define CLASS_2 2
#define CLASS_3 3

/* Quick Call to ReporterProcess */
#define REPORT \
if (pipe(fd)) {	    \
    perror("pipe"); \
  } else if ((temp_pid = fork()) == -1) { \
    perror("fork"); \
  } else if (temp_pid == 0) { \
    close(fd[0]); \
    if(DEBUG) cpu2proc(&cpu, &pcbTable[cpu.pid]); \
    reporterProcess(fd[1], pcbTable, current_time, ta, \
		    running_states, ready_states, blocked_states); \
  } else { \
    close(fd[1]); \
    while(i=(read(fd[0],&c,1)) > 0); /*Pipe Synchronization*/ \
  } \
  

char buffer[BUFSIZ];
int quantum[4];



/*INICIO ESTRUCTURAS*/

  
int readProgram(char[MAX_STR], char[MAX_LINE][MAX_STR]);
  
  
  
struct Cpu
{
  int pc; /*program counter*/
  int pid; 
  int value;
  int t_slice;  /*rodaja de tiempo*/
  int t_remain; /*tiempo que falta*/
};

struct Proc
{
  int pid;
  int ppid;
  int pc;    // Initially started from zero.
  int value;
  int priority;
  int state;
  int t_start;
  int t_used;
  char fname[MAX_STR]; // Filename to read a program
  char prog[MAX_LINE][MAX_STR]; // Programs for simulated processes.
};

struct TA_TIME{
  int times[MAX_PROCS];
  int count;
};



/*IMPLEMENTACION DE COLA*/

/*ESTRUCTURA*/
typedef struct Que {  
  int pid;
  struct Proc proc;
  struct Que *next; /* pointer to next element in list */
} QUE;


/*FUNCIONES DE COLA*/

/*insertar en la cabeza (apilar)*/
QUE *insert_head(QUE **p, int pid)
{
	  QUE *n = (QUE *) malloc(sizeof(QUE));
	  if (n == NULL) return NULL;

	  n->next = *p;
	  *p = n;

	  n->pid = pid;

	  return n;
}

/*encolar*/
QUE *enqueue(QUE **p, int pid)
{
	  QUE *tail = *p;
	  
	  if(*p == NULL) // For initial setup
		return insert_head(p, pid);

	  while(tail->next != NULL) //tail refers to a tail node
		tail = tail->next;

	  QUE *n = (QUE *) malloc(sizeof(QUE));
	  if (n == NULL)
		return NULL;

	  n->next = tail->next;
	  tail->next = n;
	  n->pid = pid;

	  return n;
}

/*desencolar*/
int dequeue(QUE **p){
	  int pid = -1;
	  if (*p != NULL){
		//printf("DEQ(pid=%d)\n", (*p)->proc.pid);
		  pid = (*p)->pid;
		  QUE *n = *p;
		  *p = n->next;
		  free(n);
		  return pid;
	  }else{
		//printf("cannot remove, because queue is empty\n");
		return pid;
	  }
}

/*FIN FUNCIONES DE COLA*/


  



/*FUNCTIONS*/
/*
 * =
 * ==
 * ===
 * ====
 * =====
 * ====
 * ===
 * ==
 * =
 * */




/*Se crea un nuevo proceso y se retorna*/
struct Proc create_proc(int pid, int ppid, int priority, int pc, int value,int t_start, int t_used, char *fname){
//Primer Proceso => pid_count++ -> [pid] , -1 -> [ppid] , CLASS_0 -> [priority], cpu.pc -> [pc], cpu.value -> [value], current_time -> [t_start], quantum[CLASS_0]-current_time ->[t_used],  init_program -> *[fname]
	  static struct Proc proc;
	  proc.pid = pid;
	  proc.ppid = ppid;
	  proc.priority = priority;
	  proc.pc = pc;
	  proc.value = value;
	  proc.t_start = t_start;
	  proc.t_used = t_used;
	  strcpy(proc.fname, fname);  
	  readProgram(proc.fname, proc.prog);
	  return proc;
}

/*Duplicar un proceso cambiando algunos valores*/
struct Proc dup_proc(struct Proc *pp, int new_pid, int dup_times, int current_time){
	  static struct Proc cp;
	  cp.pid = new_pid;
	  cp.ppid = pp->pid;
	  cp.priority = pp->priority;
	  cp.pc = pp->pc;  // Execute the instruction immediately after F instruction.
	  cp.value = pp->value;
	  cp.t_start = current_time;
	  cp.t_used = 0;
	  strcpy(cp.fname, pp->fname);
	  readProgram(cp.fname, cp.prog);
	  return cp;
} 

/*Mostrar el estado de una cola especifica*/
void show(QUE *n, struct Proc pcbTable[]){
	  struct Proc proc;
	  
	  if (n == NULL){
		printf("queue is empty\n");
		return ;
	  }
	  while (n != NULL){
		proc = pcbTable[n->pid];
		printf("pc, pid, ppid, priority, value, start time, CPU time used so far\n");
		printf("%2d, %3d,  %3d, %8d, %5d, %10d, %3d\n",
		   proc.pc, proc.pid, proc.ppid, proc.priority,
		   proc.value, proc.t_start, proc.t_used);
		n = n->next;
	  }
	  printf("\n");
	  return;
}

/*Mostrar el estado de una cola especifica por la prioridad*/
void show_by_priority(QUE *n, struct Proc pcbTable[], int priority){
	  struct Proc proc;
	  int count = 0;
	  
	  while (n != NULL){
		if(pcbTable[n->pid].priority == priority){ // por prioridad
		  proc = pcbTable[n->pid];
		  printf("pc, pid, ppid, priority, value, start time, CPU time used so far\n");
		  printf("%2d, %3d,  %3d, %8d, %5d, %10d, %3d\n",
			 proc.pc, proc.pid, proc.ppid, proc.priority,
			 proc.value, proc.t_start, proc.t_used);
		  count++;
		}
		n = n->next;
	  }
	  
	  if (count == 0){
		printf("queue is empty\n");
		return ;
	  }
	  printf("\n");
	  return;
}

/*Almacenar Cpu en un proceso*/
void cpu2proc(struct Cpu *cpu, struct Proc *proc){
	  proc->pc = cpu->pc;
	  proc->pid = cpu->pid;
	  proc->value = cpu->value;
	  proc->t_used = cpu->t_remain;
	  return;
}

/* Store a given process to a given cpu. */
void proc2cpu(struct Proc *proc, struct Cpu *cpu){
	  cpu->pc =  proc->pc;
	  cpu->pid = proc->pid;
	  cpu->value = proc->value;
	  cpu->t_slice = quantum[proc->priority];
	  if(proc->t_used > 0){ // When blocked process is assigned.
		printf("Blocked process was assigned to CPU.\n");
		cpu->t_remain = proc->t_used;
	  }else{ // When new process is assigned.
		printf("New process was assigned to CPU.\n");
		cpu->t_remain = cpu->t_slice;
	  }
	  return;
}

/* Set next priority based on a give priority. */
void set_next_priority(struct Proc *p){
	  if(p->priority == CLASS_3){
		p->priority = CLASS_3;
	  }else{
		p->priority += 1;
	  }
	  return;
}

/* Calculate a turn around time by a given current time and process. */
int calc_ta_time(int current_time, struct Proc *p){
	return current_time - p->t_start;
}

/* Calculate an average turn around time between all processes. */
double calc_ta_time_avg(struct TA_TIME ta){
	  int i;
	  int total = 0;
	  for(i=0; i<ta.count; i++){
		total += ta.times[i];
	  }
	  if(ta.count == 0){
		return 0;
	  }else{
		return total/ta.count;
	  }
}

/* Read a program by a given filename and store it to program arrays. */
int readProgram(char *fname, char prog[][MAX_STR]){
	  FILE *fp;
	  char buff[MAX_STR], *pp;
	  int x, y, i, j;
	  
	  /* Initialize program arrays */
	  for(x=0;x<MAX_LINE;x++){
		for(y=0;y<MAX_STR;y++){
		  prog[x][y] = '\0';
		}
	  }

	  fp = fopen(fname, "r");
	  if(fp == NULL){
		printf("Can't open the file: '%s'\n", fname);
		exit(1);
	  }

	  i=0;
	  //if(DEBUG) printf("Read '%s' program:\n", fname);
	  while(1){
		pp = fgets(buff, MAX_STR, fp);
		
		// delete '\n' character if exists.
		j=0;
		while(buff[j] != '\0'){
		  if(buff[j] == '\n') buff[j] = '\0';
		  j++;
		}
	  
		strcpy(prog[i], buff);
		if(pp == NULL){
		  break;
		}
		//if(DEBUG) printf("%3d: '%s'\n", i, buff);
		i++;
	  }

	  fclose(fp);
	  return(0);
}

/* Split a string by spaces and return array.*/
char **split(int *n, char *string)
{
	  char **array=NULL;
	  char *p=string;
	  char *s;

	  for(*n=0; (s = strtok(p, " ")) != NULL; (*n)++) {
		array = (char**)realloc(array, sizeof(char*) * (*n+1));
		array[*n] = s;
		p = NULL;
	  }

	  return array;
}

/* Whenever comes into a given input file descriptor,
   gives it into a output file descriptor. */
void copy(FILE *fin, FILE *fout)
{
	  while (fgets(buffer, BUFSIZ, fin) != NULL) {
		fputs(buffer, fout);
		fflush(fout);
	  }
}

/* Commander process that manipulates inputs from users,
   and send them to Process Manager process. */
void commanderProcess(int wfd) //wfd es fd[1] -> para enviar
{
	  FILE *fp = fdopen(wfd, "w"); //hace que el fp envíe lo que se escriba
	  int status;
	  //char cmd[MAX_STR];
	  
	  if (fp == NULL) {
		perror("parent: fdopen");
		exit(3);
	  }
	  copy(stdin, fp);  //lo convierte en salida standar
	  fclose(fp); //cierra el descriptor

	  if(wait(&status) == -1) {
		perror("wait");
		exit(4);
  }
}

/* Report the current status of system. */
void reporterProcess(int wfd, struct Proc pcbTable[], int time, struct TA_TIME ta,
		     QUE *s_run, QUE *s_ready, QUE *s_block){
	  int i;
	  printf("*********************************************\n");
	  printf("The current system state is as follows:\n");
	  printf("*********************************************\n");
	  printf("CURRENT TIME: %d\n", time);
	  printf("AVERAGE TURN AROUND TIME: %f.\n", calc_ta_time_avg(ta));
	  printf("\n");
	  printf("RUNNING PROCESS:\n");
	  show(s_run, pcbTable);
	  
	  printf("\n");
	  printf("BLOCKED PROCESSES:\n");
	  printf("Queue of blocked processes:\n");
	  show(s_block, pcbTable);
	  
	  printf("\n");
	  printf("PROCESSES READY TO EXECUTE:\n");

	  for(i=0; i<MAX_PRIORITY; i++){
		printf("Queue of processes with priority %d:\n", i);
		show_by_priority(s_ready, pcbTable, i);
	  }
	  
	  close(wfd); // Pipe Synchronized.
	  exit(3);
}


/*=
 * =
 * ==
 * ===
 * ====
 * */




/* Based on inputs from Commander process,
   manage all processes and share a CPU between them. */ /*Manejado por el proceso hijo.*/
void processManagerProcess(int rfd, char *init_program)
{
	/**/
	FILE *fp = fdopen(rfd, "r"); //convierte el descriptor que recepciona en un fd que recibe
	int fd[2];
	char **cmd;
	int c, n;
	int pid_count;
	int arg;
	int i/*,x*//*,y*/; // iterators
	int err_flg = false;
	int wait4unblocking = false;   // For skipping instructions when only blocked processes are remained.
  
	struct TA_TIME ta;   // For calculating average turn around time
  
	//struct Proc temp_proc;
	int temp_value;
	int temp_pid;
	char temp_fname[MAX_STR];
	int temp_index;
  
	/* ProcessManager's 6 Data Structures*/
	int current_time;
	struct Cpu cpu;
	struct Proc pcbTable[MAX_PROCS]; //Arreglo de procesos

	QUE *ready_states; // Lista de "listos"
	QUE *blocked_states; // Lista de bloqueados
	QUE *running_states; // Lista de procesos corriendo
	/**************************************/
  
	/* Initializing */  // de prioridades
	quantum[CLASS_0] = 1;  
	quantum[CLASS_1] = 2;
	quantum[CLASS_2] = 4;
	quantum[CLASS_3] = 8;
  
	pid_count = 0;
	ta.count = 0;
	ta.times[0] = 0;
	current_time = 0;
	cpu.pc = 0;
	cpu.pid = 0;
	cpu.value = 0;
	cpu.t_slice = quantum[CLASS_0]; //se inicia en "1"
	cpu.t_remain = cpu.t_slice; // se inicia en "1"
  
	//Creacion del primer proceso pcbTable[0]
	pcbTable[cpu.pid] = create_proc(pid_count++, -1, CLASS_0, cpu.pc, cpu.value,
				  current_time, quantum[CLASS_0]-current_time,
				  init_program);
  
	ready_states = NULL;
	blocked_states = NULL;
	running_states = NULL; // TODO: Re-thinking of this structure needed.

	enqueue(&running_states, cpu.pid); //encola el proceso # para su ejecución (ejecuta el proceso encolado)

	/****************/
	//if(DEBUG) show(running_states, pcbTable);
  
	while (fgets(buffer, BUFSIZ, fp) != NULL) {
    
		printf("Command = %s",buffer);
		if(!strcmp(buffer, "Q\n") || !strcmp(buffer, "q\n")){//Si es igual a Q o q

			if(wait4unblocking == true){
				printf("Only blocked processes remain, so waiting for unblocking.\n");
				printf("\n");
				printf("> ");
				fflush(stdout);
				continue;
			}
      
			printf("End of one unit of time.\n");
			printf("Instruction = '%s'\n", pcbTable[cpu.pid].prog[cpu.pc]); // muestra la instrucción actual 

			//En Caso de Error /////////////////////////////////////////////////////////////////////////////////////////
			if(!strcmp(pcbTable[cpu.pid].prog[cpu.pc], "")){
				printf("Instruccion finalizada de forma inesperada, so exit forcedlly with printing.\n");
				sprintf(cmd[0], "E");//Finaliza la ejecución del proceso simulado
				err_flg = true;
			////////////////////////////////////////////////////////////////////////////////////////////////////////////
			}else{
			cmd = split(&n, pcbTable[cpu.pid].prog[cpu.pc]); //Separa las palabras leidas
			}
      
			current_time++; //0-> 1
			cpu.pc++;       //0-> 1 
			cpu.t_remain--; //1-> 0
      		////////////////////////////////////////////////////////////////////////////////////////////////////////////
			if(!strcmp(cmd[0], "S")){  //Si es S
				printf("Iniciando el valor de la variable entera a %d.\n", atoi(cmd[1]));
				temp_value = cpu.value;
				cpu.value = atoi(cmd[1]);
				printf("CPU value: %d -> %d\n", temp_value, cpu.value); //Modifica el valor del CPU

			////////////////////////////////////////////////////////////////////////////////////////////////////////////
			}else if(!strcmp(cmd[0], "A")){ //Si es A
				printf("Add %d al valor de la variable entera.\n", atoi(cmd[1]));
				temp_value = cpu.value;
				cpu.value += atoi(cmd[1]);
				printf("CPU value: %d -> %d\n", temp_value, cpu.value); //Agrega un # al valor del CPU
	
			////////////////////////////////////////////////////////////////////////////////////////////////////////////
			}else if(!strcmp(cmd[0], "D")){ //Si es D
				printf("Substract %d del valor de la variable entera.\n", atoi(cmd[1]));
				temp_value = cpu.value;
				cpu.value -= atoi(cmd[1]);
				printf("CPU value: %d -> %d\n", temp_value, cpu.value); //Resta un # al valor del CPU
	
			////////////////////////////////////////////////////////////////////////////////////////////////////////////
			}else if(!strcmp(cmd[0], "B")){ //Si es B
				printf("Block this simulated process.\n");
				// Store CPU data to proc
				dequeue(&running_states); //Desencola el proceso de la lista de ejecución (Deja de procesar el proceso actual)
				cpu2proc(&cpu, &pcbTable[cpu.pid]); //Almacena lo de CPU en pcbTable[actual] 
				printf("Running Process(pid=%d) was blocked.\n", cpu.pid);
				enqueue(&blocked_states, cpu.pid); //encola el proceso actual en la lista de procesos
				// Scheduling required.
	
			////////////////////////////////////////////////////////////////////////////////////////////////////////////
			}else if(!strcmp(cmd[0], "E")){ //Si es E
				printf("Terminate this simulated process.\n");
				dequeue(&running_states); //Desencola el proceso de la lista en ejecución porque ya terminó
				printf("pid=%d is Terminated.\n", cpu.pid);
				ta.times[ta.count++] = calc_ta_time(current_time, &pcbTable[cpu.pid]); //calcula el tiempo de TurnAround según el proceso actual. y lo almacena en "ta"
				// Scheduling required.
	
			////////////////////////////////////////////////////////////////////////////////////////////////////////////
			}else if(!strcmp(cmd[0], "F")){ //Si es F
				printf("Create %d nuevo(s) proceso(s) simulado(s).\n", atoi(cmd[1]));
				arg = atoi(cmd[1]);
	
				cpu2proc(&cpu, &pcbTable[cpu.pid]); //Almacena lo de CPU en pcbTable[actual] antes de iniciar el nuevo proceso
				/* Duplicate a proc and enqueue it into Ready states queue. */
				
				int pid_before = pid_count;
				int pid_after  = pid_count++;
				
				pcbTable[pid_before] = dup_proc(&pcbTable[cpu.pid], pid_after,arg, current_time); //Guarda el proceso anterior
				enqueue(&ready_states, pid_count-1); //Encola el proceso anterior como "Listo"
				printf("proceso creado(pid=%d).\n", pid_count-1);
	
				cpu.pc += arg; // Execute N instructions after the next instruction. 
				// Not necessary to schdule processes.
	
			////////////////////////////////////////////////////////////////////////////////////////////////////////////
			}else if(!strcmp(cmd[0],"R")){ //Si es R
				printf("Replace the program of the simulated process with the program in the file '%s'.\n", cmd[1]);
				strcpy(temp_fname, cmd[1]);
				cpu.pc = 0;
				cpu.value = 0;
	
				readProgram(temp_fname, pcbTable[cpu.pid].prog); //Donde se reemplaza el programa por el del "File"
				//printf("Replaced the current program with the program in '%s' file.\n", temp_fname);
	
			////////////////////////////////////////////////////////////////////////////////////////////////////////////
			}else{
				printf("Unknown Instruction.\n");
				printf("Exited by error.\n");
				return;
			}      

			/*** Do scheduling ***/
			if(ready_states == NULL){ // No processes in the Ready queue, so skipped.
				if(running_states != NULL){ //Si existe algún proceso ejecutándose
					printf("No ready processes, so continue to run the current process.\n");
				}else if(blocked_states != NULL){ //Si existe algún proceso bloqueado
					printf("Only blocked processes remain, so waiting for unblocking.\n");
					wait4unblocking = true; //Espera para desbloquearse
				}else{
					//FINAL EXITOSO////////////////////////////////////////////////////////////////////////////
					// All processes were finished -> finished execution.
					if(err_flg == false) printf("Program was successfully executed.\n");
					printf("\n");
					printf("=== RESULT ===\n");
					if (pipe(fd)) {
						perror("pipe");
					} else if ((temp_pid = fork()) == -1) {
						perror("fork");
					} else if (temp_pid == 0) {
						close(fd[0]);
						if(DEBUG) cpu2proc(&cpu, &pcbTable[cpu.pid]);
						reporterProcess(fd[1], pcbTable, current_time, ta,running_states, ready_states, blocked_states);
					} else {
						close(fd[1]);
						while((i=(read(fd[0],&c,1))) > 0); // Pipe Synchronization
					}
					printf("=== END OF SYSTEM ===\n");
					return;
					/////////////////////////////////////////////////////////////////////////////////////////////////////////
				}
	
	
			}else if(running_states == NULL){ // When process was blocked or terminated.
				printf("There are no process running, so assign the first process in the queue to CPU.\n");
				temp_pid = dequeue(&ready_states); //desencola un proceso "listo" para que se ejecute
				proc2cpu(&pcbTable[temp_pid], &cpu); //según el pid del proceso... lo envía al CPU para su ejecución
				enqueue(&running_states, temp_pid); //Encola dicho proceso en la lista de ejecución
				printf("Assigned: cpu <--- pcbTable[%d]\n", temp_pid);
	
			}else if(cpu.t_remain <= 0) { // When quantum expired
				printf("Quantum was expired, so assign the first process in the que to CPU.\n");
				set_next_priority(&pcbTable[cpu.pid]); //incrementa la prioridad
				printf("Pid(%d)'s priority class was raised to %d.\n",cpu.pid, pcbTable[cpu.pid].priority);
				cpu2proc(&cpu, &pcbTable[cpu.pid]); //guarda el proceso en "memoria"
				enqueue(&ready_states, cpu.pid); //Encola el proceso en "Listo" 
				temp_pid = dequeue(&running_states); //Desencola dicho proceso de la lista de ejecución
	
				proc2cpu(&pcbTable[dequeue(&ready_states)], &cpu); //desencola el proceso de "listo" y lo manda a ejecutar por el CPU
				enqueue(&running_states, cpu.pid); //Encola dicho proceso para su ejecución (de forma legal xD)
				printf("Swithed: cpu(%d) <--> pid(%d)\n", temp_pid, cpu.pid);
	
			}else if(cpu.t_remain > 0){
				printf("CPU Time is still remained, so continue to run the current process.\n");
	
			}else{
				printf("Unknown condition to schedule.\n");
			}
				/*** End of Scheduling ***/
			free(cmd);
				/* End of One Unit of Time*/
      
		}else if(!strcmp(buffer, "U\n") || !strcmp(buffer, "u\n")){ //Si escribe U :'v
				printf("Unblock the first simulated process in blocked queue.\n");
				temp_index = dequeue(&blocked_states);
				if(temp_index == -1){
					printf("There are no states in blocked queue.\n");
				}else{
					printf("pid=%d moves from blocked queue to ready queue.\n", temp_index);
					enqueue(&ready_states, temp_index);
					wait4unblocking = false;
				}
		////////////////////////////////////////////////////////////////////////////////////////////////////////////  NUEVO  ///////////
		}else if(!strcmp(buffer, "B\n") || !strcmp(buffer, "b\n")){ //Si escribe U :'v
				
				temp_index = dequeue(&running_states); //Desencola de la lista de ejecución
				if(temp_index == -1){
					printf("There are no states in running queue.\n");
					
				}else{
					printf("block the simulated process.\n");
					cpu2proc(&cpu, &pcbTable[temp_index]); //Guarda el proceso en memoria
					enqueue(&blocked_states,temp_index); //encola en la lista de bloqueados

					printf("pid=%d moves from running queue to blocked queue.\n", temp_index);
					wait4unblocking = true;
				}
      ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		}else if(!strcmp(buffer, "P\n") || !strcmp(buffer, "p\n")){ //Si escribe P :'v
			printf("Print the current state of the system.\n");
			if (pipe(fd)) {
				perror("pipe");
			} else if ((temp_pid = fork()) == -1) {
				perror("fork");
			} else if (temp_pid == 0) { //HIJO ->  envía mensaje
				close(fd[0]);
				if(DEBUG) cpu2proc(&cpu, &pcbTable[cpu.pid]); //Guarda el proceso ejecutado del cpu
				reporterProcess(fd[1], pcbTable, current_time, ta,running_states, ready_states, blocked_states);
			} else { //PADRE -> recibe mensaje
				close(fd[1]);
				while((i=(read(fd[0],&c,1))) > 0); // Pipe Synchronization
			}

		}else if(!strcmp(buffer, "help\n")){
			printf("\
			 The following commands are accepted:\n\
			 Q:End of one unitof time\n\
			 - CPU consumes 1 instruction from programs, andexecuteit.\n\
			 U: Unblockthe first simulated process in blocked queue\n\
			 - If there is ablockedprocess, move its statefrom Blocked toReady.\n\
			 P: Print the current state of the system.\n \
				- The state include PC, PID, PPID, Priority, Value, Time, etc.\n\
			 T: Terminate the system after printing the current state.\n\
				- The printing is same as 'P' command.\n");
            
		}else if(!strcmp(buffer, "T\n") || !strcmp(buffer, "t\n")){
			printf("Print the average turnaround time, and terminate the system.\n");
			// Calculating average turnaround time.
			printf("Average turn around time is %f.\n", calc_ta_time_avg(ta));
			if (pipe(fd)) {
				perror("pipe");
			} else if ((temp_pid = fork()) == -1) {
				perror("fork");
			} else if (temp_pid == 0) { //HIJO  ->  envía mensaje
				close(fd[0]);
				if(DEBUG) cpu2proc(&cpu, &pcbTable[cpu.pid]);
				reporterProcess(fd[1], pcbTable, current_time, ta,running_states, ready_states, blocked_states);
			} else { //PADRE  -> recibe mensaje
				close(fd[1]);
				while((i=(read(fd[0],&c,1))) > 0); // Pipe Synchronization
			}
			printf("\n");
			printf("Terminate the system.\n");
			return;
      
		}else{
			printf("Unknown command.\n");
		}
			//fputs(buffer, stdout);
			printf("\n");
			printf("> ");
			fflush(stdout);
	}
	fclose(fp);
}




/*===
 * ===
 * ====
 * =====
 * ======
 * */





/*INICIO*/


/*Función main*/
int main(int argc, char *argv[]){
  int rv = 0, fd[2], pid;
  char fname[MAX_STR];

  if(argc != 2){
    printf("USAGE: ./a.out INIT_PROGRAM_NAME\n\n");
    exit(1);
  }
  printf("> ");
  strcpy(fname, argv[1]);

  if (pipe(fd)) {
    perror("pipe");
    rv = 1;
  } else if ((pid = fork()) == -1) {
    perror("fork");
    rv = 2;
  } else if (pid > 0) {//PADRE  -> envía datos
    close(fd[0]);
    commanderProcess(fd[1]); /*el padre cierra la lectura en el pipe*/
  } else {// HIJO  -> recibe datos
    close(fd[1]);
    processManagerProcess(fd[0], fname); /*el hijo cierra la escritura en el pipe*/
  }

  return rv;
}

